
select 
    'Hello, World!'   as greeting, 
    1/1               as numeric_value,
    current_timestamp as now

